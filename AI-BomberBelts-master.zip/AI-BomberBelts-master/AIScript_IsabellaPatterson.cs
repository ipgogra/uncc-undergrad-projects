﻿using UnityEngine;
using System.Collections;

public class AIScript_IsabellaPatterson : MonoBehaviour {

    public CharacterScript mainScript;

    public float[] bombSpeeds;
    public float[] buttonCooldowns;
    public float playerSpeed;
    public int[] beltDirections;
    public float[] buttonLocations;

    // added field declarations and initializations
    public int indexBestAction;
    public float score;
    public float characterLocations;

    public float[] scores new float[8];
    public float[] distancePlayerButton = new float[8];
    public float[] bombDistance;

	// Use this for initialization
	void Start () {
        mainScript = GetComponent<CharacterScript>();

        if (mainScript == null)
        {
            print("No CharacterScript found on " + gameObject.name);
            this.enabled = false;
        }

        buttonLocations = mainScript.getButtonLocations();

        playerSpeed = mainScript.getPlayerSpeed();
	}

	// update is called once per frame
	void Update () {

        buttonCooldowns = mainScript.getButtonCooldowns();
        beltDirections = mainScript.getBeltDirections();

        // added the following:

        characterLocations = mainScript.getCharacterLocation ();
        bombDistance = mainScript.getBeltDirections();
        bombSpeeds = mainScript.getBombSpeeds();

        // call and get distance from the player to the buttonCooldowns
        // and get the score

        getPlayerDistancetoButton();
		getScores();

        //	need to get the index of the belt with the highest priority

        indexBestAction = Array.IndexOf(scores, scores.Max ());
  		if (buttonLocations [indexOfBestAction]+.1 >= characterLocation) {

        //	push used for the player's desired button choice

  			if (distancePlayerButton[indexBestAction] <= .8)
  				mainScript.push ();
  			     mainScript.moveUp ();
  		} else if (buttonLocations [indexOfBestAction]-.1 <= characterLocation) {
  			if (distancePlayerButton [indexOfBestAction] <= .8)
  				mainScript.push ();
  			mainScript.moveDown ();
  		}

  	}

  	void getPlayerDistancetoButton() {
  		for (int i = 0; i < 8; i++) {	//	for each belt
  			distancePlayerButton [i] = Math.Abs (buttonLocations [i] - characterLocation) / 2;	//	get distances
  		}
  	}

  	//	score each belt based on predetermined scoring system
	// further distance == bigger number == lower score
  	void getScores () {
  		score = 0;
  		for (int i = 0; i < 8; i++) {	
  			if (bombSpeeds [i] >= 4 && bombDirections[i] == -1)
  				score += 5;
  			if (bombDirections [i] == -1)
  				score += (12-bombDistances[i]/2);	
  		    if (bombDirections[i] == 0)
  				score += 2;
  			if (buttonCooldowns [i] >= .8)
  				score -= 3;
  			score /= (distancePlayerButton [i]/3);

  			scores [i] = score;
  			score = 0;
  		}
  	}
