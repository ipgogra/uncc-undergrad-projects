# AI-BomberBelts

This repository contains the AI script for the game Bomber Belts for an assignment in Intro to AI ITCS-3153
