# EightQueens

This repoistory contains the src files for the project Eight Queens for the course ITCS-3155.
