import plotly
import plotly.express as px
from plotly.offline import plot
import plotly.graph_objs as go
import json 
import requests
import pandas as pd
from datetime import datetime

#Bayes Thrm analysis
def bayesTheorem(sensitivity = 0 , specificity = 0, prevalence = 0, situation = "+/+"):
    if situation == "+/+":
        return (sensitivity * prevalence) / ( (sensitivity * prevalence) + ((1 - specificity) * (1- prevalence)))
    
    elif situation == '-/-':
        return (specificity * (1- prevalence)) / ( (specificity * (1- prevalence))  + ((1- sensitivity) * prevalence))

#Box plot
def tablePlot(head = [], data = [], data_format = [], title = ''):
    fig = go.Figure(data=[go.Table(
        header=dict(values=list(head),
                    fill_color = 'lightskyblue',
                    line_color='slategrey',
                    align='center'),
        cells=dict(values=data,
                   fill=dict(color=['azure', 'azure']),
                   format = data_format,
                   line_color='lightskyblue',
                   align='center')),    
    ])
    fig.update_layout(title_text = title,  title_x=0.5, width=800, height=880)
    #plot(fig)
    return fig

def setup_():
    dataToReturn= []
    #data import
    url = "https://opendata.ecdc.europa.eu/covid19/casedistribution/csv"
    df_world = pd.read_csv(url)

    #date variable to index
    df_world['dateRep'] = pd.to_datetime(df_world['dateRep'], format = '%d/%m/%Y')  
    df_world.set_index('dateRep', inplace = True)
    df_world.index = pd.DatetimeIndex(df_world.index)
    

    #columns
    df_world.drop(['geoId', 'countryterritoryCode','Cumulative_number_for_14_days_of_COVID-19_cases_per_100000'],axis = 1 ,inplace = True)
    df_world.columns = ['day', 'month', 'year', 'new_case', 'new_death', 'country','population_2019', 'continent']
    df_world.dropna(inplace = True)
    df_world.loc[df_world['country'] == 'United_States_of_America', 'country'] = 'United States'

    #PCR test for sensitivity and specificity
    sensitivity_pcr = 0.70
    specificity_pcr = 0.95

    #df creation
    df_world_bayes = {'date_today' :[], 'country' : [], 'total_cases': [], 'total_death': [] , 'population' : [], 'prevalence': [], 'prob_+/+' :[], 'prob_-/-': []}
    df_world_bayes = pd.DataFrame(df_world_bayes)
    date_today = datetime.now()
    #created this to find all countries 
    #will be used to calculate Bayes result for each country
    countries = list(df_world['country'].unique())

    i = 0
    for country in countries:
        df_world_bayes.loc[i, 'date_today'] = date_today
        df_world_bayes.loc[i,'country'] = country
        df_world_bayes.loc[i, 'total_cases'] = df_world[df_world['country'] == country]['new_case'].sum()
        df_world_bayes.loc[i, 'total_death'] = df_world[df_world['country'] == country]['new_death'].sum()
        df_world_bayes.loc[i, 'population'] = df_world[df_world['country'] == country]['population_2019'].iloc[0]
        df_world_bayes.loc[i, 'prevalence'] = df_world_bayes.loc[i,'total_cases'] / df_world_bayes.loc[i, 'population']
        df_world_bayes.loc[i, 'prob_+/+'] = bayesTheorem(sensitivity = 0.70, specificity = 0.95, prevalence = df_world_bayes.loc[i, 'prevalence'], situation = '+/+')
        df_world_bayes.loc[i, 'prob_-/-'] = bayesTheorem(sensitivity = 0.70, specificity = 0.95, prevalence = df_world_bayes.loc[i, 'prevalence'], situation = '-/-') 
        i +=1

    #Top 10 Countries that has most cases in the world
    top_10_prevalence = df_world_bayes.sort_values(by = 'prevalence',ascending = False).head(10)

    #Top 10 Countries that has highest prevalence of COVID-19
    top_10_cases = df_world_bayes.sort_values(by = 'total_cases', ascending = False).head(10)

    #Prevalence tables
    dataToReturn.append(tablePlot(head = ['Countries','COVID-19 Prevalence',  'Population'], data= [top_10_cases['country'], top_10_cases['prevalence'],top_10_cases['population']],data_format = [None, '.2%', ',.d'],title = 'Probability of Having COVID-19 by Country (Highest Cases)'))
    dataToReturn.append(tablePlot(head = ['Countries','COVID-19 Prevalence',  'Population'], data= [top_10_prevalence['country'], top_10_prevalence['prevalence'],top_10_prevalence['population']],data_format = [None, '.2%', ',.d'],title = 'Probability of Having COVID-19 by Country (Highest Prevalence)'))

    #Bayes tables
    dataToReturn.append(tablePlot(head = ['Countries','COVID-19 Prevalence','Probability of +/+',   'Population'], data= [top_10_cases['country'], top_10_cases['prevalence'], top_10_cases['prob_+/+'],top_10_cases['population']],data_format = [None, '.2%', '.2%',',.d'],title = 'Probability of Having COVID-19 if Being Tested Positive by Country (Highest Cases)'))
    dataToReturn.append(tablePlot(head = ['Countries','COVID-19 Prevalence', 'Probability of +/+',  'Population'], data= [top_10_prevalence['country'], top_10_prevalence['prevalence'], top_10_prevalence['prob_+/+'],top_10_prevalence['population']],data_format = [None, '.2%', '.2%',',.d'],title = 'Probability of Having COVID-19 if Tested Positive in the World (Highest Prevalence)'))

    df_world_bayes['prevalence'] = df_world_bayes['prevalence'] * 100

    #Prevalence map for US
    fig = px.choropleth(df_world_bayes,
                  locations = 'country',
                  color='prevalence', 
                  color_continuous_scale=plotly.colors.diverging.RdYlGn[::-1],
                  locationmode='country names',
                  scope="world",
                  range_color=(0.5, 3.5),
                  height=600
                 )
    fig.update_layout( 
        title={
            'text': "COVID-19 Prevalence by Country",
            'y':0.85,
            'x':0.5,
            'xanchor': 'center',
            'yanchor': 'top'})
    #plot(fig)
    dataToReturn.append(fig)

    #Importing COVID-19 cases for the US states and their populations 
    df_us = pd.read_csv('https://data.cdc.gov/api/views/9mfq-cb36/rows.csv?accessType=DOWNLOAD')
    df_us_population = pd.read_csv('https://www2.census.gov/programs-surveys/popest/datasets/2010-2020/national/totals/nst-est2020.csv')
    #df_us_population = pd.read_csv("nst-est2020.csv")
    us_abbreviation = dict(json.loads(requests.get('https://gist.githubusercontent.com/ipgogra/2f06dc1e6cb936386e19f3f50062379d/raw/a62369e27dafcbfce25520984499259cb4ddad35/states.json').text))
    df_abbreviation = pd.DataFrame(us_abbreviation, index = [0]).T.reset_index()
    df_abbreviation.columns = ["abbreviation", 'state']

    #state abbreviations
    df_us = pd.merge(df_us, df_abbreviation, left_on = 'state', right_on = 'abbreviation', how = 'left')
    # Dropping unneccesary columns and renaming them
    df_us.drop(['conf_cases', 'prob_cases', 'pnew_case', 'conf_death', 'prob_death','pnew_death', 'created_at','consent_cases', 'consent_deaths', 'abbreviation'], axis = 1, inplace= True  )
    df_us.columns = ['date', 'abbreviation', 'total_cases', 'new_case', 'total_death', 'new_death', 'state']

    #populations column for states
    
    df_us = pd.merge(df_us.sort_values('state'), df_us_population.loc[:,['NAME', 'POPESTIMATE2020']], left_on = 'state', right_on = 'NAME', how = 'left')
    df_us.drop('NAME', axis= 1, inplace =True)
    df_us.rename(columns = {'POPESTIMATE2020': 'population'}, inplace = True)

    #dropping islands bc they don't count
    df_us[df_us['population'].isnull()]['abbreviation'].value_counts()
    df_us.dropna(inplace = True)

    #PCR test sensitivity and for specificity
    sensitivity_pcr = 0.70
    specificity_pcr = 0.95

    #List for all states. It will used to calculate states bayes results
    states = list(df_us['state'].unique()) 

    #Creating Dataframe for US bayes calculation
    df_us_bayes = {'date_today' :[],'abbreviation': [], 'state' : [], 'total_cases': [], 'total_death': [] , 'population' : [], 'prevalence': [], 'prob_+/+' :[], 'prob_-/-': []}
    df_us_bayes = pd.DataFrame(df_us_bayes)
    date_today = datetime.now()

    i = 0
    for state in states:
        df_us_bayes.loc[i, 'date_today'] = date_today
        df_us_bayes.loc[i,'abbreviation'] = df_us[df_us['state'] == state]['abbreviation'].iloc[0]
        df_us_bayes.loc[i,'state'] = state
        df_us_bayes.loc[i, 'total_cases'] = df_us[df_us['state'] == state]['new_case'].sum()
        df_us_bayes.loc[i, 'total_death'] = df_us[df_us['state'] == state]['new_death'].sum()
        df_us_bayes.loc[i, 'population'] = df_us[df_us['state'] == state]['population'].iloc[0]
        df_us_bayes.loc[i, 'prevalence'] = df_us_bayes.loc[i,'total_cases'] / df_us_bayes.loc[i, 'population']
        df_us_bayes.loc[i, 'prob_+/+'] = bayesTheorem(sensitivity = 0.70, specificity = 0.95, prevalence = df_us_bayes.loc[i, 'prevalence'], situation = '+/+')
        df_us_bayes.loc[i, 'prob_-/-'] = bayesTheorem(sensitivity = 0.70, specificity = 0.95, prevalence = df_us_bayes.loc[i, 'prevalence'], situation = '-/-') 
        i +=1

    #Top 10 States with most cases
    top_10_us_total_cases = df_us_bayes.sort_values(by = 'total_cases', ascending = False).head(10)
    #Top 10 states wtih the highest prevelance of COVID-19
    top_10_us_total_prevalence = df_us_bayes.sort_values(by = 'prevalence' ,ascending = False).head(10)

    #Prevalence table
    dataToReturn.append(tablePlot(head = ['States','COVID-19 Prevalence',  'Population'], data= [top_10_us_total_cases['state'], top_10_us_total_cases['prevalence'],top_10_us_total_cases['population']],data_format = [None, '.2%', ',.d'],title = 'Probability of Having COVID-19 by States (Highest Cases)'))
    dataToReturn.append(tablePlot(head = ['States','COVID-19 Prevalence',  'Population'], data= [top_10_us_total_prevalence['state'], top_10_us_total_prevalence['prevalence'],top_10_us_total_prevalence['population']],data_format = [None, '.2%', ',.d'],title = 'Probability of Having COVID-19 by States (Highest Prevalence)'))

    #Bayes tables
    dataToReturn.append(tablePlot(head = ['States','COVID-19 Prevalence', 'Probability of +/+',  'Population'], data= [top_10_us_total_cases['state'], top_10_us_total_cases['prevalence'], top_10_us_total_cases['prob_+/+'],top_10_us_total_cases['population']],data_format = [None, '.2%', '.2%',',.d'],title = 'Probability of Having COVID-19 if Being Tested Positive by States (Highest Cases)'))
    dataToReturn.append(tablePlot(head = ['States','COVID-19 Prevalence','Probability of +/+',   'Population'], data= [top_10_us_total_prevalence['state'], top_10_us_total_prevalence['prevalence'], top_10_us_total_prevalence['prob_+/+'],top_10_us_total_prevalence['population']],data_format = [None, '.2%', '.2%',',.d'],title = 'Probability of Having COVID-19 if Tested Positive (Highest Prevalence)'))

    #US Prevalence Map showing Bayes
    fig = px.choropleth(df_us_bayes,
                       # geojson=counties,
                  locations = 'abbreviation',
                  color='prevalence', 
                  color_continuous_scale=plotly.colors.diverging.RdYlGn[::-1],
                  locationmode='USA-states',
                  scope="usa",
                  range_color=(0.015, 0.055),

                  height=600
                 )

    fig.update_layout(
        title={
            'text': "COVID-19 Prevalence by State (US)",
            'y':0.9,
            'x':0.5,
            'xanchor': 'center',
            'yanchor': 'top'})
    #plot(fig)
    dataToReturn.append(fig)
    return dataToReturn