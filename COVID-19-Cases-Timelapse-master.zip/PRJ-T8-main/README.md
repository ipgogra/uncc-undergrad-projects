# PRJ-T8
ITCS-4122/5122 Final Group Project Repo

Streamlit application to show a timelapse of covid cases in the USA
-Shows data state by state by color coding relative amounts of infections
-Can hover over states to show specific state data for that day
-Interactible options for the timelapse such pause/play speed control forward/backwards and custom date input


Packages used:
altair
pandas
numpy
vega_datasets
streamlit
us
time
datetime

SessionState for streamlit:
https://gist.github.com/tvst/036da038ab3e999a64497f42de966a92

Dataset sources: 
(1) https://data.cdc.gov/Case-Surveillance/United-States-COVID-19-Cases-and-Deaths-by-State-o/9mfq-cb36
(2) https://www2.census.gov/programs-surveys/popest/datasets/2010-2020/national/totals/nst-est2020.csv
(3) https://opendata.ecdc.europa.eu/covid19/casedistribution/csv
