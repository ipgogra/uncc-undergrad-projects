import altair as alt
import pandas as pd
import numpy as np
from vega_datasets import data
import streamlit as st
import us
import time
import datetime
# SessionState module from https://gist.github.com/tvst/036da038ab3e999a64497f42de966a92
import SessionState
import BayesThrmAnalysis as BTA

#doesnt look good on smaller screens
#st.set_page_config(layout = 'wide')



#fetch data
url = "https://data.cdc.gov/api/views/9mfq-cb36/rows.csv?accessType=DOWNLOAD"
#using local csv to limit download requests during development
#file = "United_States_COVID-19_Cases_and_Deaths_by_State_over_Time.csv"
@st.cache
def getData():
    return pd.read_csv(url)
    #return pd.read_csv(file)
CDCData_df = getData()
#preprocess data
@st.cache
def preProcess(CDCData_df):
    #drop unused columns
    CDCData_df = CDCData_df.drop(columns = ["pnew_death", "created_at", "consent_cases", "consent_deaths"])
    #add full state names, 
    CDCData_df['full_name'] = CDCData_df.apply(lambda row: str(us.states.lookup(row['state'])), axis = 1)
    #remove non-state territories 
    toRemove = ("None","American Samoa", "Northern Mariana Islands", "Virgin Islands", "Guam", "Puerto Rico")
    for x in toRemove: 
        CDCData_df = CDCData_df[CDCData_df.full_name != x]
    #fill NaNs with 0s
    CDCData_df = CDCData_df.fillna(0)
    #change to date format so pandas can sort/understand it
    CDCData_df['submission_date'] = pd.to_datetime(CDCData_df['submission_date'], format = '%m/%d/%Y')
    #adds FIPS(Federal Information Processing Standard state code)
    CDCData_df['id'] = CDCData_df.apply(lambda row: float(us.states.lookup(row['state']).fips), axis = 1)

    #rearange for visual clarity on inspection, unnecassary for webapp
    CDCData_df = CDCData_df[['id','submission_date', 'state', 'full_name', 'tot_cases', 'conf_cases', 'prob_cases', 'new_case', 'pnew_case', 'tot_death', 'conf_death', 'prob_death', 'new_death']]
    
    #set values to floats for formating
    for x in list(CDCData_df.columns.values):
        if CDCData_df[x].dtype == int:
            CDCData_df[x] = CDCData_df[x].astype(float)
    pd.options.display.float_format = '{:,}'.format
    
    return CDCData_df

CDCData_df = preProcess(CDCData_df)



#@st.cache
def makeMap(df_day, states, fields_, color_):
    if color_ == "Total Cases":
        color = alt.Color('tot_cases',type = 'quantitative', scale = alt.Scale(scheme = 'reds'), title = "Total Cases")
    if color_ == "Total Deaths":
        color = alt.Color('tot_death',type = 'quantitative', scale = alt.Scale(scheme = 'greys'), title= "Total Deaths")
    if color_ == "New Cases":
        color = alt.Color('new_case',type = 'quantitative', scale = alt.Scale(scheme = 'purples'), title = "New Cases")
    
    Map = alt.Chart(states).mark_geoshape(
        #TODO figure out other styles, different coloring
        #fill='lightgray',
        stroke='white'
    ).encode(
        color,
        #TODO add more info here for tooltip hover, maybe
        tooltip=[alt.Tooltip('full_name:N', title= "State") , alt.Tooltip('tot_cases:Q', title = "Total Cases", format=','), alt.Tooltip('tot_death:Q', title= "Total Deaths", format=','), alt.Tooltip('new_case:Q', title = "New Cases", format=',')]
    ).transform_lookup(
        lookup='id',
        #merge map data with covid data matching by state FIP id as key    
        from_ = alt.LookupData(df_day, key = 'id', fields = fields_ )
    ).properties(
        #TODO change title maybe to match that it's over time or something
        title='US Covid Cases: ' + str(state.date),
        #slightly less than 720p
        width=1040,
        height=594
    ).project('albersUsa')
    return Map

#makes sure the date is within the boundries of the dataset, first day is hardcoded as that wont change but last day will
def validate_date(date, first_day, last_day):
    if date < first_day:
        return first_day
    if date > last_day:
        return last_day
    else:
        return date
    
#function to handle displaying the map
#takes in the dataset, and a date
#takes in an empty streamlit placeholder and redraws map on that object
#very flickery/blinky dont know how to fix
def display_map(CDCData_df, placeholder, date, color):
    df_day = CDCData_df.loc[CDCData_df['submission_date'] == date]
    #used for the fields var in lookuptransform, need to remove the column thats used as a key for streamlit to not freak out
    fields_  = list(df_day.columns.values)
    fields_.remove('id')
    x = makeMap(df_day, states, fields_, color)
    plot_map = placeholder.altair_chart(x)
    

@st.cache(allow_output_mutation=True)
def getBTA():
    return BTA.setup_()
    


#variables
#todo move elsewhere maybe
#grab USA visual from vega datasets
states = alt.topo_feature(data.us_10m.url, 'states')

#sets firt and last day
first_day = CDCData_df.sort_values(by= ['submission_date'], ascending= True).reset_index()['submission_date'][0]
last_day = (CDCData_df.sort_values(by= ['submission_date'], ascending= False).reset_index()['submission_date'][0])

#set day to first day, boolean value for animation progression, time delta(days) for animation
state = SessionState.get(date = first_day, playAnimation = False, delta = 5)
#time delta(days) for animation

st.title("Timelapse of covid cases in the US")    

#empty streamlit object used as placeholder for where map will be drawn
placeholder = st.empty()

#holds charts from bayes theorem analysis
plotly_charts = getBTA()


#sidebar
color = st.sidebar.selectbox("Colors based on:", ("Total Cases", "Total Deaths", "New Cases") )


#layout of buttons to center with map can be made more hacky if page_layout is set to wide by adding additional columns to center the buttons more
#col1, col2,, col8, col9
col3, col4, col5, col6, col7= st.beta_columns(5)
#decreases time delta by 1 min 1
if col3.button(label = "Slow down time", help = "min 1 day. Current: " + str(state.delta)):
    if state.delta - 1 < 1:
        state.delta = 1
    else:
        state.delta = state.delta - 1
#sets time 5 days back
if col4.button(label = "Backwards 5 days"):
    state.date = validate_date(state.date - datetime.timedelta(days=5), first_day, last_day)
    display_map(CDCData_df, placeholder, state.date, color)
#Animation control, animation will play an addtional time/frame after pausing no clue how to fix
if col5.button(label = "Play/Pause"):
    state.playAnimation = not state.playAnimation
#sets time 5 days forward
if col6.button(label = "Forwards 5 days"):
    state.date = validate_date(state.date + datetime.timedelta(days=5), first_day, last_day)
    display_map(CDCData_df, placeholder, state.date, color)
#increases the time delta by 1 up to 30    
if col7.button(label = "Speed up time", help = "max 30 days. Current: " + str(state.delta)):
    if state.delta + 1 > 30:
        state.delta = 30
    else:
        state.delta = state.delta + 1    

#lets user set a custom date within data set boundries     
state.date = pd.to_datetime(col5.date_input("Select date", state.date, min_value= first_day, max_value = last_day))
        
sum = CDCData_df.loc[CDCData_df['submission_date'] == state.date]["tot_cases"].sum()
col5.subheader('Total cases: ' + f"{sum:,}")  

#inital map load
display_map(CDCData_df, placeholder, state.date, color)

#Bayes Analysis
namesCharts = []
for i in plotly_charts:
    namesCharts.append(i.layout.title.text)





#animation looper
while state.playAnimation:
    
    state.date = validate_date(state.date +  datetime.timedelta(days=state.delta), first_day, last_day)
    display_map(CDCData_df, placeholder, state.date, color)
    time.sleep(1)
    #doesnt do anything to stop it early before progressing to enxt frame
    #if (not state.playAnimation):
    #    break
    if state.date == last_day:
        state.playAnimation = False
        

with st.beta_expander("Dataframe for current date"):
    df_day = CDCData_df.loc[CDCData_df['submission_date'] == state.date]
    df_day["submission_date"] = df_day.pop("submission_date")
    st.write(df_day.sort_values(by= "id"))

    
st.write("")
st.write("")
st.write("")
#st.write(namesCharts)
chart = st.selectbox("Bayes Theorem Analysis", namesCharts)
for i in plotly_charts:
    if i.layout.title.text == chart:
        st.plotly_chart(i)   
    

if st.sidebar.checkbox("Sources"):
    st.write("Dataset sources:")
    st.write("(1) https://data.cdc.gov/Case-Surveillance/United-States-COVID-19-Cases-and-Deaths-by-State-o/9mfq-cb36")
    st.write("(2) https://www2.census.gov/programs-surveys/popest/datasets/2010-2020/national/totals/nst-est2020.csv")
    st.write("(3) https://opendata.ecdc.europa.eu/covid19/casedistribution/csv")