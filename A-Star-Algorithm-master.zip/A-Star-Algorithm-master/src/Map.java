
import java.util.ArrayList;

/**
 *
 * @author Isabella Patterson
 * @class ITCS-3153
 * @assignment A* Search
 *
 */
public class Map {

    private String[][] mainMap;
    private String[][] mapPath;

    private Node[][] nodes;

    public static String noPath = "+";
    public static String Path = "-";

    private ArrayList<Node> pathway;

    private int mapSize = 15;

    public Map(String[][] map) {

        this.mainMap = map;
        this.mapSize = map.length;

        mapPath = new String[mapSize][mapSize];

        nodes = new Node[mapSize][mapSize];
        makeNodes();

    }

    public Map(String[][] m, String path, String noPath) {
        this.mainMap = m;
        this.mapSize = m.length;

        Path = path;
        noPath = noPath;

        mapPath = new String[mapSize][mapSize];

        nodes = new Node[mapSize][mapSize];
        makeNodes();

    }

    public Map() {

        mainMap = new String[mapSize][mapSize];
        makeMap();

        mapPath = new String[mapSize][mapSize];

        nodes = new Node[mapSize][mapSize];
        makeNodes();

    }

    public Map(int size) {

        mainMap = new String[mapSize][mapSize];
        makeMap();
        mapSize = size;

        mapPath = new String[mapSize][mapSize];

        nodes = new Node[mapSize][mapSize];
        makeNodes();

    }

    public void makeMap() {
        for (int i = 0; i < mapSize; i++) {
            for (int j = 0; j < mapSize; j++) {
                double probabilty = Math.random();
                if (probabilty < 0.10) {
                    mainMap[i][j] = noPath;
                } else {
                    mainMap[i][j] = Path;
                }
            }
        }
    }

    private void makeNodes() {
        for (int i = 0; i < mapSize; i++) {
            for (int j = 0; j < mapSize; j++) {
                int type = mainMap[i][j].equals(Path) ? Node.PATHABLE : Node.UNPATHABLE;
                nodes[i][j] = new Node(i, j, type);
            }
        }
    }

    public void makePath(int sRow, int sCol, int gRow, int gCol) {
        AStar astar = new AStar(nodes, sRow, sCol, gRow, gCol, mapSize);

        if (astar.isPathFound()) {
            pathway = astar.getPath();
        } else {
            pathway = null;
        }
    }

    public String showPath() {
        if (pathway == null) {
            return "A path could not be found.";
        } else {
            String result = "";
            for (int i = pathway.size() - 1; i >= 0; i--) {
                result += pathway.get(i).toString() + " ";
            }
            return result;
        }
    }

    public void updateMap() {
        resetPathMap();

        if (pathway != null) {
            int count = 1;

            for (int i = pathway.size() - 1; i >= 0; i--) {
                Node next = pathway.get(i);
                int r = next.getRow();
                int c = next.getCol();
                mapPath[r][c] = "" + count;
                count++;
            }
        }
    }

    private void resetPathMap() {
        for (int i = 0; i < mapSize; i++) {
            for (int j = 0; j < mapSize; j++) {
                mapPath[i][j] = mainMap[i][j];
            }
        }
    }

    public void resetPath() {
        pathway.clear();
    }

    public void resetNodes() {
        nodes = new Node[mapSize][mapSize];
        makeNodes();
    }

    public String[][] getMap() {
        return mainMap;
    }

    public int getMapSize() {
        return mapSize;
    }

    public String[][] getPathedMap() {
        return mapPath;
    }

    public String getType(int row, int col) {
        return mainMap[row][col];
    }

    public void setElement(int row, int column, String symbol) {
        mainMap[row][column] = symbol;
    }

    public String pathToString() {
        String r = "";

        r += "\t";
        for (int i = 0; i < mapSize; i++) {
            r += i + "\t";
        }
        r += "\n";

        for (int i = 0; i < mapSize; i++) {
            r += i + "\t";
            for (int j = 0; j < mapSize; j++) {
                r += mapPath[i][j] + "\t";
            }
            r += "\n";
        }

        return r;
    }

    public String toString() {
        String rt = "";

        rt += "\t";
        for (int i = 0; i < mapSize; i++) {
            rt += i + "\t";
        }
        rt += "\n";

        for (int i = 0; i < mapSize; i++) {
            rt += i + "\t";
            for (int j = 0; j < mapSize; j++) {
                rt += mainMap[i][j] + "\t";
            }
            rt += "\n";
        }

        return rt;
    }

}
