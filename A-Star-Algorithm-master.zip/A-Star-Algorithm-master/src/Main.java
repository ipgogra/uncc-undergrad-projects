import java.util.Scanner;

/**
 *
 * @author Isabella Patterson
 * @class ITCS-3153
 * @assignment A* Search
 * @about Main.java
 * This is the driver class for the A* Search
 * 
 */

public class Main {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        Map myMap = new Map();
        
        System.out.println("This is the starting enviroment: ");
        System.out.println("========================================\n");
        System.out.println(myMap.toString() + "\n");
        char repeat = 'N';
        
        do {
            System.out.println("Please Choose a Starting Position: ");
            System.out.println("=====================================");
            
            System.out.print("Starting Row Position: ");
            int startingRow = sc.nextInt();
            
            System.out.print("Starting Column Position: ");
            int startingColumn = sc.nextInt();

            while ((myMap.getType(startingRow, startingColumn)).equals(Map.noPath)) {
                System.out.println("Uh oh! The selected starting position is blocked D: Try again: \n");
                System.out.print("Starting Row Position: ");
                startingRow = sc.nextInt();
                
                System.out.print("Starting Column Position: ");
                startingColumn = sc.nextInt();
                
                myMap.setElement(startingRow, startingColumn, "S");
            }
            
            myMap.setElement(startingRow, startingColumn, "S");
            System.out.println("\nPlease Choose a Destination Position: ");
            System.out.println("===============================");
            
            System.out.print("Destination Row: ");
            int goalRow = sc.nextInt();
            
            System.out.print("Destination Column: ");
            int goalColumn = sc.nextInt();

            while ((myMap.getType(goalRow, goalColumn)).equals(Map.noPath)) {
                System.out.println("Whoops. The selected destination position is blocked. Try again: \n");
                System.out.print("Destination Row: ");
                goalRow = sc.nextInt();
                System.out.print("Destination Column: ");
                goalColumn = sc.nextInt();
                
                myMap.setElement(goalRow, goalColumn, "F");
            }

            myMap.setElement(goalRow, goalColumn, "F");
            
            System.out.println("\n" + myMap.toString());
            
            myMap.makePath(startingRow, startingColumn, goalRow, goalColumn);
            
            System.out.println("Path to destination: " + myMap.showPath());
            System.out.println("Final Path: ");
            System.out.println("=======================");
            myMap.updateMap();
            
            System.out.println("\n" + myMap.pathToString());
            
            System.out.print("To continue, enter Y or N: \n");
            repeat = sc.next().charAt(0);
            
            myMap.resetNodes();
            myMap.resetPath();
            
            System.out.print("\n");
            
            myMap.setElement(startingRow, startingColumn, "-");
            myMap.setElement(goalRow, goalColumn, "-");

        }while(repeat == 'Y' || repeat == 'y');
        System.out.println("Done!");
    }
}